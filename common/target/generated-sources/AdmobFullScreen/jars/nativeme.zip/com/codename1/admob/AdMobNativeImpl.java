package com.codename1.admob;

public class AdMobNativeImpl {
    public void init(String param) {
    }

    public boolean isLoaded() {
        return false;
    }

    public void showAd() {
    }

    public boolean loadAd() {
        return false;
    }

    public boolean isSupported() {
        return false;
    }

}
