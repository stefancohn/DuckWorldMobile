namespace com.codename1.admob{

using System;
using System.Windows;

public class AdMobNativeImpl {
    public void init(String param) {
    }

    public bool isLoaded() {
        return false;
    }

    public void showAd() {
    }

    public bool loadAd() {
        return false;
    }

    public bool isSupported() {
        return false;
    }

}
}
